package com.example.missionmad2.models

data class RecipeModel (
    var empId: String? = null,
    var empName: String? = null,
    var empAge: String? = null,
    var empIns : String? = null,

        )
