package com.example.missionmad2.models

data class groceryModel (
    var empId: String? = null,
    var empName: String? = null,
    var empAge: String? = null,


        )
