package com.example.missionmad2.models

data class pantryModel (
    var empId: String? = null,
    var empName: String? = null,
    var empAge: String? = null,


        )
