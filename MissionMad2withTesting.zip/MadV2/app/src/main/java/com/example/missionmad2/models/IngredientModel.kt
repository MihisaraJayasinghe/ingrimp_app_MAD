package com.example.missionmad2.models

data class IngredientModel (
    var empId: String? = null,
    var empName: String? = null,
    var empAge: String? = null,


        )
