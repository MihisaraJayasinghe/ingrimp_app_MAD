<h1 align="center">Ingrimp App MAD</h1>

<p align="center">
    <img src= ![IngrimpLogo](https://github.com/MihisaraJayasinghe/ingrimp_app_MAD/assets/99629832/e7ee8de4-a83e-4ca8-919e-0109cc7da441) alt="Ingrimp App Logo">
</p>

<p align="center">
    2nd-year 2nd-semester Mobile Application Development (MAD) project.
</p>

## Development Branch

This branch contains the release-ready version of the app. It includes all the integrated activities except for Login and Home. Additionally, there are two buttons in the navigation bar to easily access those activities for navigation.

### App Appearance (UI)

The current UI design is in need of improvement. The header and navigation bar have been fully implemented and styled.

<p align="center">
    <img src=![IngrimpLogo](https://github.com/MihisaraJayasinghe/ingrimp_app_MAD/assets/99629832/e7ee8de4-a83e-4ca8-919e-0109cc7da441)
  alt="App Screenshot">
</p>

Feel free to contribute and enhance the app's visual appeal!

 
